"use strict";

const AthenaExpress = require("athena-express"),
    aws = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const athenaExpressConfig = {
    aws,
    db: "geocore_metadata",
    getStats: true
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);

exports.handler = async(event, context, callback) => {
    
    var uuid = event.id;
    var lang = event.lang;

    var id = "COALESCE(features_properties_id, 'N/A') AS id";
    var coordinates = "features_geometry_coordinates AS coordinates";
    var publication_date = "COALESCE(features_properties_date_published_date, 'N/A') AS published";
    var options = "TRY(CAST(features_properties_options AS JSON)) AS options";
    var contact = "TRY(CAST(features_properties_contact AS JSON)) AS contact";
    var topicCategory = "COALESCE(features_properties_topicCategory, 'N/A') AS topicCategory";
    var created_date = "COALESCE(features_properties_date_created_date, 'N/A') AS created";
    var spatialRepresentation = "COALESCE(features_properties_spatialRepresentation, 'N/A') AS spatialRepresentation";
    var type = "COALESCE(features_properties_type, 'N/A') AS type";
    var temporalExtent = "MAP_FROM_ENTRIES(ARRAY[('begin', features_properties_temporalExtent_begin), ('end', features_properties_temporalExtent_end)]) AS temporalExtent";
    var graphicOverview = "features_properties_graphicOverview AS graphicOverview";
    var language = "COALESCE(features_properties_language, 'N/A') AS language";
    var refSys = "COALESCE(features_properties_refSys, 'N/A') AS refSys";
    var refSys_version = "COALESCE(features_properties_refSys_version, 'N/A') AS refSys_version";
    var status = "COALESCE(features_properties_status, 'N/A') AS status";
    var maintenance = "COALESCE(features_properties_maintenance, 'N/A') AS maintenance";
    var metadataStandard = "COALESCE(features_properties_metadataStandard_en, 'N/A') AS metadataStandard";
    var metadataStandardVersion = "COALESCE(features_properties_metadataStandardVersion, 'N/A') AS metadataStandardVersion";
    var distributionFormat_name = "COALESCE(features_properties_distributionFormat_name, 'N/A') AS distributionFormat_name";
    var distributionFormat_format = "COALESCE(features_properties_distributionFormat_format, 'N/A') AS distributionFormat_format";
    var accessConstraints = "COALESCE(features_properties_accessConstraints, 'N/A') AS accessConstraints";
    var otherConstraints = "COALESCE(features_properties_otherConstraints_en, 'N/A') AS otherConstraints";
    var dateStamp = "COALESCE(features_properties_dateStamp, 'N/A') AS dateStamp";
    var dataSetURI = "COALESCE(features_properties_dataSetURI, 'N/A') AS dataSetURI";
    var locale = "MAP_FROM_ENTRIES(ARRAY[('language', features_properties_locale_language), ('country', features_properties_locale_country), ('encoding', features_properties_locale_encoding)]) AS locale";
    var characterSet = "COALESCE(features_properties_characterSet, 'N/A') AS characterSet";
    var environmentDescription = "COALESCE(features_properties_environmentDescription, 'N/A') as environmentDescription";
    var supplementalInformation = "COALESCE(features_properties_supplementalInformation_en, 'N/A') AS supplementalInformation";
    var credits = "TRY(CAST(features_properties_credits AS JSON)) AS credits";
    var cited = "TRY(CAST(features_properties_cited AS JSON)) AS cited";
    var distributor = "TRY(CAST(features_properties_distributor AS JSON)) AS distributor";
    var title_en = "COALESCE(features_properties_title_en, 'N/A') AS title_en";
    var title_fr = "COALESCE(features_properties_title_fr, 'N/A') AS title_fr";
    
    let keywords;
    let description;
    let useLimits;
    
    if (lang === "fr") {
        
        keywords = "COALESCE(features_properties_keywords_fr, 'N/A') AS keywords";
        description = "COALESCE(features_properties_description_fr, 'N/A') AS description";
        useLimits = "COALESCE(features_properties_useLimits_fr, 'N/A') AS useLimits";
        
    } else {
        
        keywords = "COALESCE(features_properties_keywords_en, 'N/A') AS keywords";
        description = "COALESCE(features_properties_description_en, 'N/A') AS description";
        useLimits = "COALESCE(features_properties_useLimits_en, 'N/A') AS useLimits";
        
    }

    //var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + options + ", " + contact + ", " + topicCategory + ", " + created_date + ", " + spatialRepresentation + ", " + type + ", " + temporalExtent + ", " + graphicOverview + ", " + language + ", " + refSys + "";
    //, " + supplementalInformation + ", " + credits + ", " + distributor + "";

    var display_fields = "" + id + ", " + coordinates + ", " + title_en + ", " + title_fr + ", " + description + ", " + publication_date + ", " + keywords + ", " + options + ", " + contact + ", " + topicCategory + ", " + created_date + ", " + spatialRepresentation + ", " + type + ", " + temporalExtent + ", " + refSys + ", " + refSys_version + ", " + status + ", " + maintenance + ", " + metadataStandard + ", " + metadataStandardVersion + ", " + graphicOverview + ", " + distributionFormat_name + ", " + distributionFormat_format + ", " + useLimits + ", " + accessConstraints + ", " + otherConstraints + ", " + dateStamp + ", " + dataSetURI + ", " + locale + ", " + language + ", " + characterSet + ", " + environmentDescription + ", " + supplementalInformation + ", " + credits + ", " + distributor + "";

    let sqlQuery;
    

    sqlQuery = "SELECT " + display_fields + " FROM metadata WHERE features_properties_id = '" + uuid + "'";
    

    try {
        let results = await athenaExpress.query(sqlQuery);

        //var response = {};

        // console.log(response);
        //console.log(results);
        //context.succeed(response);
        callback(null, results);
    }

    catch (error) {
        callback(error, null);
    }
};