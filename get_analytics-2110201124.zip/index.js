"use strict";

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */
 
const axios = require('axios');
 
const AthenaExpress = require("athena-express"),
	AWS = require("aws-sdk");

const athenaExpressConfig = {
    aws: AWS,
    db: "default",
    catalog: "dynamodb-analytics"
};

const athenaExpressConfig1 = {
    aws: AWS,
    db: "geocore_metadata"
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);
const athenaExpress1 = new AthenaExpress(athenaExpressConfig1);

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});
const tableName = "tag";
const theme_tableName = "theme";


global.results;
global.pre_results;
global.pre_results_1;
global.lang;
global.theme;
global.min;
global.max;
global.keyword_only;

global.org;
global.uuid;
global.results_preArray;
global.results_Array = [];
global.keyword_uuid;
global.results_Array_results_string;

global.response;
global.response_final;
global.response_data = [];
global.response_data_1;
global.response_data_result;
global.response_data_final = [];
global.response_data_final_1;
global.response_data_final_result;
global.response_data_final_results_string;
global.response_Array_1;
global.response_data_results_string;

global.responseA_data_result;
global.responseA_data = [];
global.responseA_data_results_string;
global.responseA_data_1;
global.responseA;

global.responseB_data_result;
global.responseB_data = [];
global.responseB_data_results_string;
global.responseB_data_1;
global.responseB;

global.response_82;

global.theme_search = '';

global.legal_scan_results = [];
global.legal_scan_result;
global.legal_scan_results_string;
global.legal_1;

global.emergency_scan_results = [];
global.emergency_scan_result;
global.emergency_scan_results_string;
global.emergency_1;

global.foundational_scan_results = [];
global.foundational_scan_result;
global.foundational_scan_results_string;

global.admin;
global.economy;
global.environment;
global.imagery;
global.infrastructure;
global.science;
global.society;
global.legal;
global.emergency;


var keywords;
var title;
var description;
var organisation;
var id;
var coordinates;
var topicCategory;
var publication_date;


const uuids = [];

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var type;
    if (event.type === ''||event.type === ""||typeof event.type === 'undefined') {
        type = undefined;
    } else {
        type = event.type;
    }
    
    var theme_lower;
    if (event.theme === ''||event.theme === ""||typeof event.theme === 'undefined') {
        global.theme = undefined;
    } else {
        theme_lower = event.theme;
        global.theme = theme_lower.toLowerCase();
    }
    
    var org;
    var org_lower;
    if (event.org === ''||event.org === ""||typeof event.org === 'undefined') {
        org = undefined;
    } else {
        org_lower = event.org;
        org = org_lower.toLowerCase();
    }
    
    var query_id = event.id;
    
    global.lang = event.lang;
    global.min = '1';
    global.max = '10000';
    global.keyword_only = 'true';
    global.uuid = event.uuid;


 function one() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT search, COUNT(*) AS count FROM analytics WHERE date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p') >= current_date - interval '30' day AND type = 'search' GROUP BY search ORDER BY count DESC LIMIT 10";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

 function two() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS searches FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', current_date) AND type = 'search'";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

 function three() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', current_date) AND (type = 'access' OR type = 'use')";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}
    
 function four_one() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', current_date) AND (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            resolve();
        
        });
        
}

 function four_two() {
      
        return new Promise(async function(resolve) {
            
            global.pre_results.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
            
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features[1].properties.id, 'N/A') AS id";
            coordinates = "features[1].geometry.coordinates AS coordinates";
            topicCategory = "COALESCE(features[1].properties.topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features[1].properties.date.published.date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features[1].properties.keywords.fr, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.fr, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features[1].properties.keywords.en, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.en, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features[1].properties.id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.pre_results.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                    global.results = global.results_Array;
                            
                    });
            });

            
            resolve();
            
      });

}

 function five_one() {
      
        return new Promise(async function(resolve) {
            
            global.pre_results = [];
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            resolve();
        
        });
        
}

 function five_two() {
      
        return new Promise(async function(resolve) {
            
            global.pre_results.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
            
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features[1].properties.id, 'N/A') AS id";
            coordinates = "features[1].geometry.coordinates AS coordinates";
            topicCategory = "COALESCE(features[1].properties.topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features[1].properties.date.published.date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features[1].properties.keywords.fr, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.fr, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features[1].properties.keywords.en, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.en, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features[1].properties.id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.pre_results.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                    global.results = global.results_Array;
                            
                    });
            });

            
            resolve();
            
      });

}

function six() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS searches FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', (date_add('month', -1, current_date))) AND type = 'search'";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

 function seven() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', (date_add('month', -1, current_date))) AND (type = 'access' OR type = 'use')";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            global.results = global.pre_results;

            resolve();
        
        });
        
}

 function eight_one() {
      
        return new Promise(async function(resolve) {
            
            id = "COALESCE(features[1].properties.id, 'N/A') AS id";
            
            let sqlQuery1;
            
            sqlQuery1 = "SELECT " + id + " FROM metadata WHERE " + global.theme_search + "";
            
            await athenaExpress1.query(sqlQuery1)
            .then(function (response){
                global.responseA_data = [];
                
                response.Items.forEach(function(result, index, array) {
                
                    global.responseA_data_result = result.id + "|";
                    global.responseA_data.push(global.responseA_data_result); 
                
                });
                
                global.responseA_data_results_string = String(global.responseA_data);
                global.responseA_data_1 = global.responseA_data_results_string.replace(/\,/g, '');
                global.responseA = global.responseA_data_1.slice(0, -1);
                //console.log(global.responseA);
            });
                    
        resolve();

        });

}

 function eight_two() {
      
        return new Promise(async function(resolve) { 
            
            let sqlQuery;
            
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE regexp_like(uuid, '" + global.responseA + "') AND (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";
            
            await athenaExpress.query(sqlQuery)
            .then(function (response){

                global.response_82 = response;
                
            });
            
            resolve();
            
      });

}

 function eight_three() {
      
        return new Promise(async function(resolve) {
            
            global.responseB_data = [];
            
            global.response_82.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
                
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features[1].properties.id, 'N/A') AS id";
            coordinates = "features[1].geometry.coordinates AS coordinates";
            topicCategory = "COALESCE(features[1].properties.topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features[1].properties.date.published.date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features[1].properties.keywords.fr, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.fr, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features[1].properties.keywords.en, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.en, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features[1].properties.id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                global.results_Array = [];
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.response_82.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var accesses = '"acceses": "' + access_number + '"';
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                    global.results = global.results_Array;
                            
                    });
            });

            
            resolve();
            
      });

}

 function nine_one() {
      
        return new Promise(async function(resolve) {
            
            id = "COALESCE(features[1].properties.id, 'N/A') AS id";
            var organisation_filter = "regexp_like(COALESCE(CAST(json_extract(json_array_get(json_parse(LOWER(features[1].properties.contact)), 0), '$.organisation.en') AS VARCHAR), 'N/A'), '" + org + "')";
        
            let sqlQuery1;
            
            sqlQuery1 = "SELECT " + id + " FROM metadata WHERE " + organisation_filter + "";
            
            await athenaExpress1.query(sqlQuery1)
            .then(function (response){
                global.responseA_data = [];
                
                response.Items.forEach(function(result, index, array) {
                
                    global.responseA_data_result = result.id + "|";
                    global.responseA_data.push(global.responseA_data_result); 
                
                });
                
                global.responseA_data_results_string = String(global.responseA_data);
                global.responseA_data_1 = global.responseA_data_results_string.replace(/\,/g, '');
                global.responseA = global.responseA_data_1.slice(0, -1);
                //console.log(global.responseA);
            });
                    
        resolve();

        });

}

 function nine_two() {
      
        return new Promise(async function(resolve) { 
            
            let sqlQuery;
            
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE regexp_like(uuid, '" + global.responseA + "') AND (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";
            
            await athenaExpress.query(sqlQuery)
            .then(function (response){

                global.response_82 = response;
                
            });
            
            resolve();
            
      });

}

 function nine_three() {
      
        return new Promise(async function(resolve) {
            
            global.responseB_data = [];
            
            global.response_82.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
                
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features[1].properties.id, 'N/A') AS id";
            coordinates = "features[1].geometry.coordinates AS coordinates";
            topicCategory = "COALESCE(features[1].properties.topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features[1].properties.date.published.date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features[1].properties.keywords.fr, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.fr, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features[1].properties.keywords.en, 'N/A') AS keywords";
                title = "COALESCE(features[1].properties.title.en, 'N/A') AS title";
                description = "COALESCE(features[1].properties.description.en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features[1].properties.id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                global.results_Array = [];
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.response_82.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var accesses = '"acceses": "' + access_number + '"';
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                    global.results = global.results_Array;
                            
                    });
            });

            
            resolve();
            
      });

}

 function ten() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses FROM analytics WHERE (uuid = '" + global.uuid + "' AND date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', current_date)) AND (type = 'access' OR type = 'use')";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            let sqlQuery_1;
            
            sqlQuery_1 = "SELECT COUNT(*) AS accesses FROM analytics WHERE uuid = '" + global.uuid + "' AND (type = 'access' OR type = 'use')";
            
            global.pre_results_1 = await athenaExpress.query(sqlQuery_1);
            
            
            global.results = {
                "all": global.pre_results_1.Items[0].accesses,
                "30": global.pre_results.Items[0].accesses
            };
            
            //global.results = global.response;

            resolve();
        
        });
        
}


function themes() {
    
    return new Promise(resolve => {

    if (typeof global.theme !== 'undefined') {
    
    if (global.theme.includes('administration')) {
        global.admin = "boundaries|planning_cadastre|location";
    } else {
        global.admin = "";
    }
    
    if (global.theme.includes('economy')) {
        global.economy = "economy|farming";
    } else {
        global.economy = "";
    }
    
    if (global.theme.includes('environment')) {
        global.environment = "biota|environment|elevation|inland_waters|oceans|climatologyMeteorologyAtmosphere";
    } else {
        global.environment = "";
    }
    
    if (global.theme.includes('imagery')) {
        global.imagery = "imageryBaseMapsEarthCover";
    } else {
        global.imagery = "";
    }
    
    if (global.theme.includes('infrastructure')) {
        global.infrastructure = "structure|transport|utilitiesCommunication";
    } else {
        global.infrastructure = "";
    }
    
    if (global.theme.includes('science')) {
        global.science = "geoscientificInformation";
    } else {
        global.science = "";
    }
    
    if (global.theme.includes('society')) {
        global.society = "health|society|intelligenceMilitary";
    } else {
        global.society = "";
    }
    
    var pre_theme_string = global.admin + global.economy + global.environment + global.imagery + global.infrastructure + global.science + global.society;
    //var pre_theme_string_trim = pre_theme_string.slice(0, -1);
    
    if (global.theme.includes('legal')) {
    
        var params = {
            TableName: theme_tableName,
            FilterExpression: "tag = :tag",
            ExpressionAttributeValues: {
                ":tag":{"S":"legal"},
        }};
        
        dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            data.Items.forEach(function(result, index, array) {
                
                global.legal_scan_result = result.uuid.S + "|";
                global.legal_scan_results.push(global.legal_scan_result); 
                
            });
            
        }
        
        global.legal_scan_results_string = String(global.legal_scan_results);
        global.legal_1 = global.legal_scan_results_string.replace(/\,/g, '');
        global.legal = global.legal_1.slice(0, -1);
        
        });

    }
    
    if (global.theme.includes('emergency')) {
        
        params = {
        TableName: theme_tableName,
        FilterExpression: "tag = :tag",
        ExpressionAttributeValues: {
            ":tag":{"S":"emergency"},
        }};
        
        dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            data.Items.forEach(function(result, index, array) {
                
                global.emergency_scan_result = result.uuid.S + "|";
                global.emergency_scan_results.push(global.emergency_scan_result); 
                
            });
            
        }
        
        global.emergency_scan_results_string = String(global.emergency_scan_results);
        global.emergency_1 = global.emergency_scan_results_string.replace(/\,/g, '');
        global.emergency = global.emergency_1.slice(0, -1);
        
        });
        
    }
    
    var pre_tag_theme_string = global.legal + global.emergency;
    var pre_tag_theme_string_trim = String(pre_tag_theme_string).slice(0, -1);
    
    
    if ( global.theme.includes('administration')||global.theme.includes('economy')||global.theme.includes('environment')||global.theme.includes('imagery')||global.theme.includes('infrastructure')||global.theme.includes('science')||global.theme.includes('society') ) {
        
        if (!global.theme.includes('legal')||!global.theme.includes('emergency')) {
            
            global.theme_search = "regexp_like(features[1].properties.topicCategory, '" + pre_theme_string + "')";
            
        } else {
            
            global.theme_search = "regexp_like(features[1].properties.topicCategory, '" + pre_theme_string + "') AND regexp_like(features[1].properties.id, '" + pre_tag_theme_string_trim + "')";
             
        }
    
    } 
    
    if (global.theme.includes('legal')||global.theme.includes('emergency')) { 
        
        if (!global.theme.includes('administration')||!global.theme.includes('economy')||!global.theme.includes('environment')||!global.theme.includes('imagery')||!global.theme.includes('infrastructure')||!global.theme.includes('science')||!global.theme.includes('society') ) {
        
            global.theme_search = "regexp_like(features[1].properties.id, '" + pre_tag_theme_string_trim + "')";
    
        } else {
            
            global.theme_search = "regexp_like(features[1].properties.topicCategory, '" + pre_theme_string + "') AND regexp_like(features[1].properties.id, '" + pre_tag_theme_string_trim + "')";
        }
    }
    
    
}   

    resolve();
    });
}

function time() {
        return new Promise(resolve => {
        setTimeout(() => {
            console.log(global.pre_results);
        resolve();
        }, 500);
    });
    } 

if (query_id === '1') {
    
    await one();
    
}
    
if (query_id === '2') {
    
    await two();
    
}
    
if (query_id === '3') {

    await three();
    
}

if (query_id === '4') {
    
    await four_one();
    await time();
    await four_two();
    
}

if (query_id === '5') {
    
    await five_one();
    await time();
    await five_two();
    
}

if (query_id === '6') {
    
    await six();
    
}
 
if (query_id === '7') {
    
    await seven();
    
}

if (query_id === '8') {
    
    await themes();
    await eight_one();
    await eight_two();
    await eight_three();
    
}

if (query_id === '9') {
    
    await nine_one();
    await nine_two();
    await nine_three();
    
}

if (query_id === '10') {
    
    await ten();
    
}
        
    //console.log(results);
    
    let results = global.results;
    //console.log(global.response);
    
    callback(null, results);
};