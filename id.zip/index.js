"use strict";

const AthenaExpress = require("athena-express"),
    aws = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const athenaExpressConfig = {
    aws,
    db: "level1_metadata",
    getStats: true
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);

exports.handler = async(event, context, callback) => {
    
    var uuid = event.id;
    var lang = event.lang;

    var id = "COALESCE(features[1].properties.id, 'N/A') AS id";
    var coordinates = "features[1].geometry.coordinates AS coordinates";
    var publication_date = "COALESCE(features[1].properties.date.published.date, 'N/A') AS published";
    var options = "TRY(CAST(features[1].properties.options AS JSON)) AS options";
    var contact = "TRY(CAST(features[1].properties.contact AS JSON)) AS contact";
    var topicCategory = "COALESCE(features[1].properties.topicCategory, 'N/A') AS topicCategory";
    var created_date = "COALESCE(features[1].properties.date.created.date, 'N/A') AS created";
    var spatialRepresentation = "COALESCE(features[1].properties.spatialRepresentation, 'N/A') AS spatialRepresentation";
    var type = "COALESCE(features[1].properties.type, 'N/A') AS type";
    var temporalExtent = "TRY(features[1].properties.temporalExtent) AS temporalExtent";
    var graphicOverview = "CAST(features[1].properties.graphicOverview AS JSON) AS graphicOverview";
    var language = "COALESCE(features[1].properties.language, 'N/A') AS language";
    var refSys = "COALESCE(features[1].properties.refSys, 'N/A') AS refSys";
    var refSys_version = "COALESCE(features[1].properties.refSys_version, 'N/A') AS refSys_version";
    var status = "COALESCE(features[1].properties.status, 'N/A') AS status";
    var maintenance = "COALESCE(features[1].properties.maintenance, 'N/A') AS maintenance";
    var metadataStandard = "COALESCE(features[1].properties.metadataStandard.en, 'N/A') AS metadataStandard";
    var metadataStandardVersion = "COALESCE(features[1].properties.metadataStandardVersion, 'N/A') AS metadataStandardVersion";
    var distributionFormat_name = "COALESCE(features[1].properties.distributionFormat_name, 'N/A') AS distributionFormat_name";
    var distributionFormat_format = "COALESCE(features[1].properties.distributionFormat_format, 'N/A') AS distributionFormat_format";
    var useLimits = "COALESCE(features[1].properties.useLimits.en, 'N/A') AS useLimits";
    var accessConstraints = "COALESCE(features[1].properties.accessConstraints, 'N/A') AS accessConstraints";
    var otherConstraints = "COALESCE(features[1].properties.otherConstraints.en, 'N/A') AS otherConstraints";
    var dateStamp = "COALESCE(features[1].properties.dateStamp, 'N/A') AS dateStamp";
    var dataSetURI = "COALESCE(features[1].properties.dataSetURI, 'N/A') AS dataSetURI";
    var locale = "TRY(features[1].properties.locale) AS locale";
    var characterSet = "COALESCE(features[1].properties.characterSet, 'N/A') AS characterSet";
    var environmentDescription = "COALESCE(features[1].properties.environmentDescription, 'N/A') as environmentDescription";
    var supplementalInformation = "COALESCE(features[1].properties.supplementalInformation.en, 'N/A') AS supplementalInformation";
    var credits = "TRY(CAST(features[1].properties.credits AS JSON)) AS credits";
    var cited = "TRY(CAST(features[1].properties.cited AS JSON)) AS cited";
    var distributor = "TRY(CAST(features[1].properties.distributor AS JSON)) AS distributor";
    
    let keywords;
    let title;
    let description;

    if (lang === "fr") {
        
        keywords = "COALESCE(features[1].properties.keywords.fr, 'N/A') AS keywords";
        title = "COALESCE(features[1].properties.title.fr, 'N/A') AS title";
        description = "COALESCE(features[1].properties.description.fr, 'N/A') AS description";
        
    } else {
        
        keywords = "COALESCE(features[1].properties.keywords.en, 'N/A') AS keywords";
        title = "COALESCE(features[1].properties.title.en, 'N/A') AS title";
        description = "COALESCE(features[1].properties.description.en, 'N/A') AS description";
        
    }

    //var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + options + ", " + contact + ", " + topicCategory + ", " + created_date + ", " + spatialRepresentation + ", " + type + ", " + temporalExtent + ", " + graphicOverview + ", " + language + ", " + refSys + "";
    //, " + supplementalInformation + ", " + credits + ", " + distributor + "";

    var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + options + ", " + contact + ", " + topicCategory + ", " + created_date + ", " + spatialRepresentation + ", " + type + ", " + temporalExtent + ", " + refSys + ", " + refSys_version + ", " + status + ", " + maintenance + ", " + metadataStandard + ", " + metadataStandardVersion + ", " + graphicOverview + ", " + distributionFormat_name + ", " + distributionFormat_format + ", " + useLimits + ", " + accessConstraints + ", " + otherConstraints + ", " + dateStamp + ", " + dataSetURI + ", " + locale + ", " + language + ", " + characterSet + ", " + environmentDescription + ", " + supplementalInformation + ", " + credits + ", " + distributor + "";

    let sqlQuery;
    

    sqlQuery = "SELECT " + display_fields + " FROM metadata WHERE features[1].properties.id = '" + uuid + "'";
    

    try {
        let results = await athenaExpress.query(sqlQuery);

        //var response = {};

        // console.log(response);
        //console.log(results);
        //context.succeed(response);
        callback(null, results);
    }

    catch (error) {
        callback(error, null);
    }
};