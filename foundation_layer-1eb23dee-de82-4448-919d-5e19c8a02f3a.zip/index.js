"use strict";

const AthenaExpress = require("athena-express"),
 aws = require("aws-sdk");

const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const athenaExpressConfig = {
    aws,
    db: "level1_metadata",
    getStats: true
};

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});
const tableName = "tag";

const athenaExpress = new AthenaExpress(athenaExpressConfig);

var params = {};
var scan_results_1;
var scan_results_2;
var scan_results = [];
var scan_result;
var scan_results_string;
var foundational_tag;
var foundational_result;
var foundational_results = [];
var foundational_results_string;
var foundational_results_1;
var foundational_results_2;

exports.handler = async (event, context, callback) => {
    
    var north = event.north;
    var east = event.east;
    var south = event.south;
    var west = event.west;
    var keyword = event.keyword;
    
    var min;
    if (typeof event.min === 'undefined') {
        min = "0";
    } else {
        min = event.min;
    }
    
    var max;
    if (typeof event.max === 'undefined') {
        max = "1000";
    } else {
        max = event.max;
    }
    
    var keyword_only = event.keyword_only;
    var lang = event.lang;
    var theme = event.theme;
    
    var id = "COALESCE(features[1].properties.id, 'N/A') AS id";
    var coordinates = "features[1].geometry.coordinates AS coordinates";
    var publication_date = "COALESCE(features[1].properties.date.published.date, 'N/A') AS published";
    var options = "TRY(CAST(features[1].properties.options AS JSON)) AS options";
    var contact = "TRY(CAST(features[1].properties.contact AS JSON)) AS contact";
    var topicCategory = "COALESCE(features[1].properties.topicCategory, 'N/A') AS topicCategory";
    var created_date = "COALESCE(features[1].properties.date.created.date, 'N/A') AS created";
    var spatialRepresentation = "COALESCE(features[1].properties.spatialRepresentation, 'N/A') AS spatialRepresentation";
    var type = "COALESCE(features[1].properties.type, 'N/A') AS type";
    var temporalExtent = "TRY(features[1].properties.temporalExtent) AS temporalExtent";
    var graphicOverview = "CAST(features[1].properties.graphicOverview AS JSON) AS graphicOverview";
    var language = "COALESCE(features[1].properties.language, 'N/A') AS language";

    //var refSys = "COALESCE(features[1].properties.refSys, 'N/A') AS refSys";
    //var refSys_version = "COALESCE(features[1].properties.refSys_version, 'N/A') AS refSys_version";
    //var status = "COALESCE(features[1].properties.status, 'N/A') AS status";
    //var maintenance = "COALESCE(features[1].properties.maintenance, 'N/A') AS maintenance";
    //var metadataStandard = "COALESCE(features[1].properties.metadataStandard.en, 'N/A') AS metadataStandard";
    //var metadataStandardVersion = "COALESCE(features[1].properties.metadataStandardVersion, 'N/A') AS metadataStandardVersion";
    //var distributionFormat_name = "COALESCE(features[1].properties.distributionFormat_name, 'N/A') AS distributionFormat_name";
    //var distributionFormat_format = "COALESCE(features[1].properties.distributionFormat_format, 'N/A') AS distributionFormat_format";
    //var useLimits = "COALESCE(features[1].properties.useLimits.en, 'N/A') AS useLimits";
    //var accessConstraints = "COALESCE(features[1].properties.accessConstraints, 'N/A') AS accessConstraints";
    //var otherConstraints = "COALESCE(features[1].properties.otherConstraints.en, 'N/A') AS otherConstraints";
    //var dateStamp = "COALESCE(features[1].properties.dateStamp, 'N/A') AS dateStamp";
    //var dataSetURI = "COALESCE(features[1].properties.dataSetURI, 'N/A') AS dataSetURI";
    //var locale = "TRY(features[1].properties.locale) AS locale";
    //var characterSet = "COALESCE(features[1].properties.characterSet, 'N/A') AS characterSet";
    //var environmentDescription = "COALESCE(features[1].properties.environmentDescription, 'N/A') as environmentDescription";
    //var supplementalInformation = "COALESCE(features[1].properties.supplementalInformation.en, 'N/A') AS supplementalInformation";
    //var credits = "TRY(CAST(features[1].properties.credits AS JSON)) AS credits";
    //var cited = "TRY(CAST(features[1].properties.cited AS JSON)) AS cited";
    //var distributor = "TRY(CAST(features[1].properties.distributor AS JSON)) AS distributor";
    
    var id_search = "regexp_like(features[1].properties.id, '" + keyword + "')";
    var topicCategory_search = "regexp_like(features[1].properties.topicCategory, '" + keyword + "')";
    
    let keywords;
    let title;
    let description;
    let keyword_search;
    let description_search;
    let title_search;
    let organisation;
    
    if (lang === "fr") {
        
        keywords = "COALESCE(features[1].properties.keywords.fr, 'N/A') AS keywords";
        title = "COALESCE(features[1].properties.title.fr, 'N/A') AS title";
        description = "COALESCE(features[1].properties.description.fr, 'N/A') AS description";
        organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
        keyword_search = "regexp_like(features[1].properties.keywords.fr, '" + keyword + "')";
        description_search = "regexp_like(features[1].properties.description.fr, '" + keyword + "')";
        title_search = "regexp_like(features[1].properties.title.fr, '" + keyword + "')";
        
    } else {
        
        keywords = "COALESCE(features[1].properties.keywords.en, 'N/A') AS keywords";
        title = "COALESCE(features[1].properties.title.en, 'N/A') AS title";
        description = "COALESCE(features[1].properties.description.en, 'N/A') AS description";
        organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features[1].properties.contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
        keyword_search = "regexp_like(features[1].properties.keywords.en, '" + keyword + "')";
        description_search = "regexp_like(features[1].properties.description.en, '" + keyword + "')";
        title_search = "regexp_like(features[1].properties.title.en, '" + keyword + "')";
        
    }

    var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + options + ", " + contact + ", " + topicCategory + ", " + created_date + ", " + spatialRepresentation + ", " + type + ", " + temporalExtent + ", " + graphicOverview + ", " + language + ", " + organisation + "";
    //, " + supplementalInformation + ", " + credits + ", " + distributor + "";

    //var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + options + ", " + contact + ", " + topicCategory + ", " + created_date + ", " + spatialRepresentation + ", " + type + ", " + temporalExtent + ", " + refSys + ", " + refSys_version + ", " + status + ", " + maintenance + ", " + metadataStandard + ", " + metadataStandardVersion + ", " + graphicOverview + ", " + distributionFormat_name + ", " + distributionFormat_format + ", " + useLimits + ", " + accessConstraints + ", " + otherConstraints + ", " + dateStamp + ", " + dataSetURI + ", " + locale + ", " + language + ", " + characterSet + ", " + environmentDescription + ", " + supplementalInformation + ", " + credits + ", " + distributor + "";
    
        
   let theme_search = '';
    
    if (theme === "administration") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'boundaries|planning_cadastre|location')";
    }
    
    if (theme === "economy") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'economy|farming')";
    }
    
    if (theme === "environment") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'biota|environment|elevation|inland_waters|oceans|climatology_meterology_atmosphere')";
    }
    
    if (theme === "imagery") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'imagery_base_maps_earth_cover')";
    }
    
    if (theme === "infrastructure") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'structure|transport|utilities_communication')";
    }
    
    if (theme === "science") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'geoscientific_information')";
    }
    
    if (theme === "society") {
        theme_search = "regexp_like(features[1].properties.topicCategory, 'health|society|intelligence_military')";
    }
    
    if (theme === "legal") {
    
        params = {
            TableName: tableName,
            FilterExpression: "tag = :tag",
            ExpressionAttributeValues: {
                ":tag":{"S":"legal"},
        }};
        
        let legal_scan = await dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            data.Items.forEach(function(result, index, array) {
                
                scan_result = "^" + result.uuid.S + "$|";
                scan_results.push(scan_result); 
                
            });
            
        }
        
        scan_results_string = String(scan_results);
        scan_results_1 = scan_results_string.replace(/\,/g, '');
        scan_results_2 = scan_results_1.slice(0, -1);
        
        });
        

        theme_search = "regexp_like(features[1].properties.id, '" + scan_results_2 + "')";

    }

    if (theme === "emergency") {
        
        params = {
        TableName: tableName,
        FilterExpression: "tag = :tag",
        ExpressionAttributeValues: {
            ":tag":{"S":"emergency"},
        }};
        
        let emergency_scan = await dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            data.Items.forEach(function(result, index, array) {
                
                scan_result = "^" + result.uuid.S + "$|";
                scan_results.push(scan_result); 
                
            });
            
        }
        
        scan_results_string = String(scan_results);
        scan_results_1 = scan_results_string.replace(/\,/g, '');
        scan_results_2 = scan_results_1.slice(0, -1);
        
        });
        

        theme_search = "regexp_like(features[1].properties.id, '" + scan_results_2 + "')";

    }
    
    foundational_tag = {
            TableName: tableName,
            FilterExpression: "tag = :tag",
            ExpressionAttributeValues: {
                ":tag":{"S":"foundational"},
            }
    };
        
    let foundation_scan = await dynamodb.scan(foundational_tag, function(err, data) {
        
    if (err) {
        console.log("Error", err);
    } else {
            
        data.Items.forEach(function(result, index, array) {
                
            foundational_result = "^" + result.uuid.S + "$|";
            foundational_results.push(foundational_result); 
                
        });
            
    }
        
    foundational_results_string = String(foundational_results);
    foundational_results_1 = foundational_results_string.replace(/\,/g, '');
    foundational_results_2 = foundational_results_1.slice(0, -1);
    
    });
        
    let foundational = "regexp_like(features[1].properties.id, '" + foundational_results_2 + "')";
    console.log(foundational);
    
    let sqlQuery;
    
    if (typeof theme === 'undefined') {
        sqlQuery = "SELECT " + display_fields + " FROM metadata WHERE " + foundational + "";
    } else {

    sqlQuery = "SELECT " + display_fields + " FROM (SELECT * FROM metadata WHERE " + foundational + ") WHERE " + theme_search + "";
    
    }
    
    try {
        let results = await athenaExpress.query(sqlQuery);

        //var response = {};

        // console.log(response);
        //console.log(results);
        //context.succeed(response);
        callback(null, results);
    }

    catch (error) {
        callback(error, null);
    }
};